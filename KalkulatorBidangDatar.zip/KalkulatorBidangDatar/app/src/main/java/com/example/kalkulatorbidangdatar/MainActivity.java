package com.example.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText einput1, einput2, eluas, ekeliling;
    Button b1, b2, b3, brst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        einput1 = (EditText) findViewById(R.id.einput1);
        einput2 = (EditText) findViewById(R.id.einput2);
        eluas = (EditText) findViewById(R.id.eluas);
        ekeliling = (EditText) findViewById(R.id.ekeliling);

        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        b3 = (Button) findViewById(R.id.b3);
        brst = (Button) findViewById(R.id.brst);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (einput1.length()==0&&einput2.length()==0){
                    Toast.makeText(getApplication(),"Panjang dan Lebar Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else if (einput1.length()==0){
                    Toast.makeText(getApplication(),"Panjang Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else if (einput2.length()==0){
                    Toast.makeText(getApplication(),"Lebar Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else {
                    int panjang = Integer.parseInt(einput1.getText().toString());
                    int lebar = Integer.parseInt(einput2.getText().toString());
                    int luas = panjang * lebar;
                    eluas.setText(String.valueOf(luas));
                    int kelling = 2 * panjang + 2 * lebar;
                    ekeliling.setText(String.valueOf(kelling));

                }
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (einput1.length()==0&&einput2.length()==0){
                    Toast.makeText(getApplication(),"Alas dan Tinggi Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else if (einput1.length()==0){
                    Toast.makeText(getApplication(),"Alas Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else if (einput2.length()==0){
                    Toast.makeText(getApplication(),"Tinggi Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else {
                    int alas = Integer.parseInt(einput1.getText().toString());
                    int tinggi = Integer.parseInt(einput2.getText().toString());
                    int luas = tinggi * alas / 2;
                    eluas.setText(String.valueOf(luas));
                    int kelling = 3 * alas;
                    ekeliling.setText(String.valueOf(kelling));

                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (einput1.length()==0){
                    Toast.makeText(getApplication(),"Diameter Tidak Boleh Kosong",Toast.LENGTH_LONG).show();
                }
                else {
                    int diameter = Integer.parseInt(einput1.getText().toString());
                    double phi = 3.14;
                    double luas = phi * diameter * diameter / 4;
                    eluas.setText(String.valueOf(luas));
                    double kelling = phi * diameter;
                    ekeliling.setText(String.valueOf(kelling));

                }
            }
        });
        brst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                einput1.setText("");
                einput2.setText("");
                eluas.setText("");
                ekeliling.setText("");
            }
        });


    }
}